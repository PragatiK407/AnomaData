import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import missingno as msno

# Load the data
data = pd.read_excel('../data/raw/AnomaData.xlsx')

# Data overview
print(data.info())
print(data.describe())

# Check for missing values
msno.matrix(data)

# Correlation heatmap
plt.figure(figsize=(12, 8))
sns.heatmap(data.corr(), cmap='coolwarm', annot=False)
plt.title('Correlation Matrix')
plt.savefig('../visuals/correlation_matrix.png')
plt.show()

# Distribution of the target variable
sns.countplot(x='y', data=data)
plt.title('Distribution of Target Variable (y)')
plt.show()

# Save the cleaned and processed data
data.to_csv('../data/processed/AnomaData_processed.csv', index=False)
